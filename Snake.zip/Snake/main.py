import pygame
import random

# Initialize pygame
pygame.init()

# Set up the game window
WINDOW_WIDTH = 800
WINDOW_HEIGHT = 800
game_window = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
pygame.display.set_caption("Snake Game")

# Define colors
BLACK = (0, 0, 0)
WHITE = (240, 248, 255)
GREEN = (0, 255, 0)
GRAY = (50, 50, 50)
AQUAMARINE = (69,139,116)
DARKOLIVEGREEN = (85,107,47)
RED = (238,44,44)

# Define the snake and food
snake_block_size = 20
snake_speed = 14
font_style = pygame.font.SysFont(None, 55)
large_font = pygame.font.SysFont(None, 80)

def draw_snake(snake_block_size, snake_list):
    for x in snake_list:
        pygame.draw.rect(game_window, WHITE, [x[0], x[1], snake_block_size, snake_block_size])

def message(msg, color):
    msg = font_style.render(msg, True, color)
    game_window.blit(msg, [WINDOW_WIDTH/2 - msg.get_width()/2, WINDOW_HEIGHT/2.6 - msg.get_height()/2]) #PRESS C TO TRY AGAIN
    msg2 = large_font.render("YOU LOST!", True, RED)
    game_window.blit(msg2, [WINDOW_WIDTH / 2 - msg2.get_width() / 1.7, WINDOW_HEIGHT / 4]) #YOU LOST!

def game_loop():
    game_over = False
    game_close = False
    score = 0

    # Starting position of the snake
    x1 = WINDOW_WIDTH / 2
    y1 = WINDOW_HEIGHT / 2

    # Change in position of the snake
    x1_change = 0
    y1_change = 0

    # Define the snake and food
    snake_list = []
    Length_of_snake = 1

    foodx = round(random.randrange(0, WINDOW_WIDTH - snake_block_size) / 20.0) * 20.0
    foody = round(random.randrange(0, WINDOW_HEIGHT - snake_block_size) / 20.0) * 20.0

    # Start the game loop
    while not game_over:

        while game_close == True:
            game_window.fill(DARKOLIVEGREEN)
            message("Press Q to Quit or Press C to Play Again", WHITE)
            score_text = score_font.render("Final Score: " + str(score), True, WHITE)
            game_window.blit(score_text, [WINDOW_WIDTH / 2 - score_text.get_width() / 2, WINDOW_HEIGHT / 2 + score_text.get_height()])
            score_font = pygame.font.SysFont(None, 70)
            pygame.display.update()

            for event in pygame.event.get():
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_q:
                        game_over = True
                        game_close = False
                    if event.key == pygame.K_c:
                        game_loop()

        # Check for events
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                game_over = True
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    x1_change = -snake_block_size
                    y1_change = 0
                elif event.key == pygame.K_RIGHT:
                    x1_change = snake_block_size
                    y1_change = 0
                elif event.key == pygame.K_UP:
                    y1_change = -snake_block_size
                    x1_change = 0
                elif event.key == pygame.K_DOWN:
                    y1_change = snake_block_size
                    x1_change = 0

        # Check if snake goes out of bounds
        if x1 >= WINDOW_WIDTH or x1 < 0 or y1 >= WINDOW_HEIGHT or y1 < 0:
            game_close = True

        # Update the position of the snake
        x1 += x1_change
        y1 += y1_change

        # Draw the food and snake on the screen
        game_window.fill(DARKOLIVEGREEN)
        pygame.draw.rect(game_window, RED, [foodx, foody, snake_block_size, snake_block_size])
        snake_Head = []
        snake_Head.append(x1)
        snake_Head.append(y1)
        snake_list.append(snake_Head)

        if len(snake_list) > Length_of_snake:
            del snake_list[0]

        for x in snake_list[:-1]:
            if x == snake_Head:
                game_close = True

        draw_snake(snake_block_size, snake_list)
        # Draw the score on the screen
        score_font = pygame.font.SysFont(None, 40)
        score_text = score_font.render("Score: " + str(score), True, WHITE)
        game_window.blit(score_text, (10, 10))

        pygame.display.update()

        # Check if the snake has hit the food
        if x1 == foodx and y1 == foody:
            foodx = round(random.randrange(0, WINDOW_WIDTH - snake_block_size) / 20.0) * 20.0
            foody = round(random.randrange(0, WINDOW_HEIGHT - snake_block_size) / 20.0) * 20.0
            Length_of_snake += 1
            score += 10

        # Update the game clock
        clock = pygame.time.Clock()
        clock.tick(snake_speed)

    # Deactivate pygame library
    pygame.quit()

game_loop()